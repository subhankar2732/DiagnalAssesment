import React from 'react';
import ContentListing from './components/ContentListing';
import './App.css';

function App() {
    return (
        <div className="App">
            <ContentListing />
        </div>
    );
}

export default App;
