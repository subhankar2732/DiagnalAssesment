import React, { useState } from 'react';
import backButtonImage from '../images/back.png';
import searchIcon from '../images/search.png';

const Header = ({ searchTerm, setSearchTerm }) => {
    const handleBackButtonClick = () => {
        if (window.confirm("Do you really want to exit the app?")) {
            window.close(); // This will only work in certain environments like Electron.
        }
    };

    const handleSearchChange = (event) => {
        setSearchTerm(event.target.value);
    };

    return (
        <header>
            <button onClick={handleBackButtonClick}>
                <img src={backButtonImage} alt="Back" className="icon back-icon" />
            </button>
            <span>Romantic Comedy</span>
            <div className="search-container">
                <input
                    type="text"
                    placeholder="Search..."
                    value={searchTerm}
                    onChange={handleSearchChange}
                />
                <img src={searchIcon} alt="Search" className="icon search-icon" />
            </div>
        </header>
    );
};

export default Header;
