import React, { useState, useEffect, useCallback } from 'react';
import { fetchPageData, fetchImage } from '../api';
import Header from './Header';
import '../styles/ContentListing.css';

const ContentListing = () => {
    const [data, setData] = useState([]);
    const [page, setPage] = useState(1);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        loadMoreData();
    }, []);

    const loadMoreData = () => {
        fetchPageData(page).then(response => {
            setData(prevData => [...prevData, ...response.data.page['content-items'].content]);
            setPage(prevPage => prevPage + 1);
        });
    };

    const handleScroll = useCallback(() => {
        if (window.innerHeight + document.documentElement.scrollTop !== document.documentElement.offsetHeight) return;
        loadMoreData();
    }, [page]);

    useEffect(() => {
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, [handleScroll]);

    const filteredData = data.filter(item => item.name.toLowerCase().includes(searchTerm.toLowerCase()));

    return (
        <div className="content-listing">
            <Header searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
            <div className="grid">
                {filteredData.map((item, index) => (
                    <div className="grid-item" key={index}>
                        <img 
                            src={fetchImage(item['poster-image'])} 
                            alt={item.name} 
                            onError={(e) => e.target.src = '../images/defaultimage.png'} 
                        />
                        <div className="item-name">{item.name}</div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ContentListing;
