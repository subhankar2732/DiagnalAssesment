import React, { useState, useEffect, useRef, useCallback } from 'react';
import LazyLoad from 'react-lazyload';
import ContentItem from './ContentItem';
import { fetchPageData } from '../services/dataService';

const ContentGrid = () => {
  const [data, setData] = useState([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const observer = useRef(null);

  useEffect(() => {
    loadData(1);
  }, []);

  useEffect(() => {
    if (loading || !hasMore) return;

    const options = {
      root: null,
      rootMargin: '0px',
      threshold: 1.0,
    };

    observer.current = new IntersectionObserver(handleObserver, options);
    const target = document.querySelector('.bottom');
    if (target) observer.current.observe(target);

    return () => {
      if (observer.current && target) observer.current.unobserve(target);
    };
  }, [loading, hasMore]);

  const handleObserver = useCallback((entries) => {
    const target = entries[0];
    if (target.isIntersecting && hasMore && !loading) {
      loadData(page + 1);
    }
  }, [hasMore, loading, page]);

  const loadData = async (pageNum) => {
    setLoading(true);
    try {
      const newData = await fetchPageData(pageNum);
      if (newData.length === 0) {
        setHasMore(false);
      } else {
        setData((prevData) => [...prevData, ...newData]);
        setPage(pageNum);
      }
    } catch (error) {
      console.error('Error loading data:', error);
      setHasMore(false); // Prevent further loading attempts on error
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="content-grid">
      <div className="grid-container">
        {data.map((item, index) => (
          <LazyLoad key={index} height={200}>
            <ContentItem key={index} item={item} />
          </LazyLoad>
        ))}
      </div>
      {loading && <div className="loading">Loading...</div>}
      <div className="bottom" />
    </div>
  );
};

export default ContentGrid;
