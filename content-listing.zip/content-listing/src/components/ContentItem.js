import React from 'react';

const ContentItem = ({ item }) => {
  return (
    <div className="content-item">
      <img src={`https://test.create.diagnal.com/images/${item['poster-image']}`} alt={item.name} />
      <p>{item.name}</p>
    </div>
  );
};

export default ContentItem;
