import React from 'react';
import backIcon from '../images/back.png';
import searchIcon from '../images/search.png';

const Header = () => {
  return (
    <div className="header">
      <img src={backIcon} alt="Back" />
      <div className="header-title">Romantic Comedy</div>
      <img src={searchIcon} alt="Search" />
    </div>
  );
};

export default Header;
